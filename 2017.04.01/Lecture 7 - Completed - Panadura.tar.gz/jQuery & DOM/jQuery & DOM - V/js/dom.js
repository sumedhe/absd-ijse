$(window).on("load",function(){
   //$("#div-loader").css("display","none");
});
$(document).ready(function(){
    for (var i = 0; i < 100000; i++) {
        console.log("Just for delaying");
    }
});






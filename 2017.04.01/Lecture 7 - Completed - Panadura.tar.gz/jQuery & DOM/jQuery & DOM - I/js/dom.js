$('#message').text("Hi, I am learning JQuery");
$('#txt-name').html($('#txt-name').html() + '<input type="text" />');
$('#header-title').css('color','red');
$('#no-image').attr("alt","Sorry, No image to show here");
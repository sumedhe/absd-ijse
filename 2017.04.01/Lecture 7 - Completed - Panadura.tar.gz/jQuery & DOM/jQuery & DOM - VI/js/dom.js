$( function() {
    $( "#draggable" ).draggable();
    $("h1").draggable();
} );
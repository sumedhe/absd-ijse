var myObj = {
    name    : "IJSE",
    age     : 8
}

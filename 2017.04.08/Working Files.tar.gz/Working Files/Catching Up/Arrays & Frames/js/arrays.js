var message = "I am a variable of index.html";

var myarray = [10,20,30];
var output = $("#output");
var myString = "Hi, If you have any sort of RegEx related problems, just contact IJSE : 071-1202202. \
                All of your problems will vanish in seconds.";
output.append("MyString : " + myString + "<hr>");


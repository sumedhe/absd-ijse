$(document).ready(function(){
    $("#txtFullName").focus();
});
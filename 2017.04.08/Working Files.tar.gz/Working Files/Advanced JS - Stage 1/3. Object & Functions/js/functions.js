function myFn1(){
    console.log("This is function declaration");
}

var myFn2 = function(){
    console.log("This is function expression");
}
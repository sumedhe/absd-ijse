
$(document).ready(function() {

    setInterval(function() {
        var curDate = new Date();
        $("#datenTime").html("<span style='padding-right:10px' class='glyphicon glyphicon-time'></span>" + curDate.toUTCString());

    }, 10);

    $("#sideBar li").mousedown(function() {
        removeAllActiveClasses();
        $(this).addClass("active");
        if ($(this).text() !== "Dashboard") {
            $("#divMenuPath").html(
                    '<a href="#" onclick="gotoDash()"><span class="glyphicon glyphicon-home" style="margin-right:10px"></span>Dashboard <span class="glyphicon glyphicon-chevron-right" style="margin:0px 10px"></span></a>'
                    + $(this).text().toString());
        } else {
            $("#divMenuPath").html(
                    '<a href="#"><span class="glyphicon glyphicon-home" style="margin-right:10px"></span>Dashboard</a>'
                    );
        }
        $("#divMenuTitle>h2").html($(this).children().html());
    });
    // Handling navigation of the side bar
    $("#sideBar li").click(function() {

// First hide all divs
        $("#divTarget").children("div").css('display', 'none');
        switch ($(this).text()) {
            case "Dashboard":
                $("#divTarget #divDashboard").css('display', 'block');
                break;
            case "Customers":
                initCustomers();
                $("#divTarget #divCustomers").css('display', 'block');
                break;
        }
    });
    // Customers form's functions go here 

    {

        var selectedRadio = "name"; // By default
        var txtSearch = $("#frmSearchCustomer input[name='txtSearchQuery']");
        var btnSerch = $("#frmSearchCustomer #cusSearchBtn");
        $("#frmSearchCustomer input[name='rdSearchQuery']:radio").change(function() {
            if ($(this).val() === "NIC") {
                $("#frmSearchCustomer #cusNICV").css("display", '');
                txtSearch.attr("maxlength", 9);
                selectedRadio = "NIC";
            } else {
                var maxL = ($(this).val() !== "name") ? 10 : '';
                txtSearch.attr("maxlength", maxL);
                $("#frmSearchCustomer #cusNICV").css("display", 'none');
                selectedRadio = (maxL === 10) ? "tel" : "name";
            }

            txtSearch.attr("placeholder", "Enter customer's " + $(this).val());
            txtSearch.focus();
            txtSearch.select();
        });
        txtSearch.keyup(function() {
            if (txtSearch.val().toString().trim().length !== 0) {
                if (btnSerch.attr("disabled") === "disabled") {
                    btnSerch.removeAttr("disabled");
                }
            } else {
                btnSerch.attr("disabled", '');
            }
        });
        txtSearch.keypress(function(event) {
            if (event.which === 13) {
                event.preventDefault();
                btnSerch.click();
            }
        });
        btnSerch.click(function(event) {
            /* Validation Part */

            var divParentOfTxt = $(txtSearch.parent("div"));
            if (divParentOfTxt.hasClass("has-error")) {
                divParentOfTxt.removeClass("has-error");
            }

            var divOutput = $("#frmSearchCustomer #divCusSearcBoxOutput");
            divOutput.css("display", 'none');
            if (selectedRadio === "NIC" || selectedRadio !== "name") {

                var num = txtSearch.val().toString();
                if (num.match(new RegExp("[^0-9]", ''))) {

                    $(txtSearch.parent("div")).addClass("has-error");
                    if (selectedRadio === "NIC")
                        divOutput.html("Invalid NIC number. Please use only digits [0-9]");
                    else
                        divOutput.html("Invalid Telephone number. Please use only digits [0-9]");
                    divOutput.css("display", 'block');
                    txtSearch.focus();
                    txtSearch.select();
                } else {

                    if (selectedRadio === "NIC" && num.trim().length < 9) {
                        $(txtSearch.parent("div")).addClass("has-error");
                        divOutput.html("Invalid NIC number. There should be nine digits for NIC number");
                        divOutput.css("display", 'block');
                        txtSearch.focus();
                        txtSearch.select();
                    } else if (selectedRadio === "tel" && num.trim().length < 10) {
                        $(txtSearch.parent("div")).addClass("has-error");
                        divOutput.html("Invalid Telephone number. It should contain ten digits.");
                        divOutput.css("display", 'block');
                        txtSearch.focus();
                        txtSearch.select();
                    }

                }
            }
        });
        // View all customers
        $("#divCustomers :button").filter("[name=btnViewAllCustomer]").click(function() {

            // Generate customers html
            var cusHTML = '';
            for (var i = 0; i < 20; i++) {
                cusHTML = cusHTML +
                        //"<tr><td>" + "C" + i + "</td><td>Jane Dones</td></tr>"    //< td > No: 475, Gampha, Colombo < /td>< td > 123456789V < /td>< td > 0111234567 < /td> < td > 1980 - 01 - 01 < /td><tr>";                            
                        "<tbody><tr><td>" + "C" + i + "</td><td>Jane Dones </td><td> No: 475, Gampha, Colombo </td><td> 123456789V </td><td> 0111234567 </td> <td> 1980 - 01 - 01 </td><tr></tbody>";
            }

            console.log(cusHTML);

            $("#divCustomers #tblCustomers").html(
                    $("#divCustomers #tblCustomers").html() +
                    cusHTML
                    );
        });
    }

});
function removeAllActiveClasses() {
    var listItems = $("#sideBar li");
    for (var i = 0; i < listItems.length; i++) {
        if ($(listItems[i]).hasClass("active")) {
            $(listItems[i]).removeClass("active");
        }
    }
}

function gotoDash() {
    removeAllActiveClasses();
    $("#listDashboard").addClass("active");
    $("#divMenuTitle>h2").html($("#listDashboard").children().html());
    $("#divMenuPath").html(
            '<a href="#"><span class="glyphicon glyphicon-home" style="margin-right:10px"></span>Dashboard</a>'
            );
}

function initCustomers() {

// Checked the name radio button
    $("#frmSearchCustomer input[value='name']:radio").prop('checked', true);
    $("#frmSearchCustomer input[value='name']:radio").change();
    // Clear the text box and focus
    var txtBox = $("#frmSearchCustomer input[name='txtSearchQuery']");
    txtBox.val("");
}